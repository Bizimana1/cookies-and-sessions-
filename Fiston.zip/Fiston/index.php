﻿<?php include'login.php';  ?>

<?php include'loginpage.php';  ?>
<?php

$_SESSION["status"]="";

?>

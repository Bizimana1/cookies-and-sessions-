<?php

include'header.php';

?>


<head>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div>
<marquee> WELCOME TO this PAge</marquee>
</div>
<div>


</body>
</html>